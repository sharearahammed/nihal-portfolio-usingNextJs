"use client";

import Link from "next/link";
import { personalInfo } from "@/lib/data";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function CTASection() {
  const sectionRef  = useRef<HTMLElement>(null);
  const cardRef     = useRef<HTMLDivElement>(null);
  const glowRef     = useRef<HTMLDivElement>(null);
  const contentRef  = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {

      // ── Card entrance: scale up from below with blur
      gsap.fromTo(
        cardRef.current,
        { y: 80, opacity: 0, scale: 0.93, filter: "blur(8px)" },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          filter: "blur(0px)",
          duration: 1.1,
          ease: "expo.out",
          scrollTrigger: {
            trigger: cardRef.current,
            start: "top 82%",
          },
        }
      );

      // ── Content items stagger in
      gsap.fromTo(
        contentRef.current?.querySelectorAll(".cta-item") ?? [],
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.14,
          ease: "power3.out",
          scrollTrigger: {
            trigger: cardRef.current,
            start: "top 75%",
          },
        }
      );

      // ── Glow pulsing parallax as you scroll through
      gsap.to(glowRef.current, {
        scale: 1.6,
        opacity: 0.18,
        ease: "none",
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top bottom",
          end: "bottom top",
          scrub: 2,
        },
      });

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="py-28"
      style={{ borderTop: "1px solid var(--border)" }}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div
          ref={cardRef}
          className="relative overflow-hidden rounded-2xl text-center py-20 px-8"
          style={{
            background: "var(--bg-card)",
            border: "1px solid var(--border)",
          }}
        >
          {/* Parallax glow blob */}
          <div
            ref={glowRef}
            className="absolute inset-0 pointer-events-none"
            style={{
              background: "radial-gradient(ellipse at center, rgba(249,115,22,0.1) 0%, transparent 65%)",
              transformOrigin: "center center",
            }}
          />

          {/* Decorative corner lines */}
          <div
            className="absolute top-0 left-0 w-24 h-24 pointer-events-none"
            style={{
              borderTop: "1px solid rgba(249,115,22,0.25)",
              borderLeft: "1px solid rgba(249,115,22,0.25)",
              borderRadius: "0 0 0 0",
            }}
          />
          <div
            className="absolute bottom-0 right-0 w-24 h-24 pointer-events-none"
            style={{
              borderBottom: "1px solid rgba(249,115,22,0.25)",
              borderRight: "1px solid rgba(249,115,22,0.25)",
            }}
          />

          <div ref={contentRef} className="relative z-10">
            <p className="cta-item section-label mb-5">Get In Touch</p>
            <h2
              className="cta-item text-sm md:text-4xl lg:text-5xl font-bold mb-6"
              style={{ fontFamily: "Syne, sans-serif", color: "var(--text-primary)" }}
            >
              {personalInfo.email}
            </h2>
            <p className="cta-item text-xs sm:text-sm mb-10 max-w-md mx-auto" style={{ color: "var(--text-secondary)" }}>
              Have a project in mind? Let&apos;s collaborate and build something amazing together.
            </p>
            <div className="cta-item flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact" className="btn-brand">
                Start a Project
              </Link>
              <a href={`mailto:${personalInfo.email}`} className="btn-outline">
                Send Email
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
